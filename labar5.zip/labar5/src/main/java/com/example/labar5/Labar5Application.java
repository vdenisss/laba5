package com.example.labar5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labar5Application {

    public static void main(String[] args) {
        SpringApplication.run(Labar5Application.class, args);
    }

}
