package com.example.labar5.repository;

import com.example.labar5.model.Feetback;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeatbackRepository extends JpaRepository<Feetback, Integer> {
}
