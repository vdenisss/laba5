package com.example.labar5.repository;

import com.example.labar5.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, JpaRepository> {
}
